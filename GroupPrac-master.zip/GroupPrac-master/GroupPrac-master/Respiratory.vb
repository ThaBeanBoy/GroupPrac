﻿' ***************************************************************** 
' Team Number: 20
' Team Member 1 Details: Chipoyera, TG (220150124) 
' Team Member 2 Details: Hlebela, JM (221026973) 
' Team Member 3 Details: NDHLOVU, AJ(221020749) 
' Team Member 4 Details: Ntuli, SD (221076674) 
' Practical: Team Project 
' Class name: Respiratory 
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer On

<Serializable()> Public Class Respiratory
    'Inheriting from Disease
    Inherits Disease

    'Attributes
    Private _PartAffected As String
    Private _AveNumOfCoughs As Double

    '<<Constructor>>
    Public Sub New(Name As String, TotalPopulation As Integer)
        MyBase.New(Name, TotalPopulation)
    End Sub

    '<<Property Methods>>
    Public Property PartAffected() As String
        Get
            Return _PartAffected
        End Get
        Set(value As String)
            _PartAffected = value
        End Set
    End Property

    Public Property AverageNumberOfCoughs() As Double
        Get
            Return _AveNumOfCoughs
        End Get
        Set(value As Double)
            _AveNumOfCoughs = ValidateDouble(value)
        End Set
    End Property

    Public Overrides Function display() As String
        Dim Ans As String = MyBase.display() & Environment.NewLine
        Ans &= "Part Affected: " & _PartAffected & Environment.NewLine
        Ans &= "Average number of coughs: " & Format(_AveNumOfCoughs, ".##") & Environment.NewLine
        Return Ans
    End Function
End Class
