﻿' ***************************************************************** 
' Team Number: 20
' Team Member 1 Details: Chipoyera, TG (220150124) 
' Team Member 2 Details: Hlebela, JM (221026973) 
' Team Member 3 Details: NDHLOVU, AJ(221020749) 
' Team Member 4 Details: Ntuli, SD (221076674) 
' Practical: Team Project 
' Class name: Genetic
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer On

<Serializable()> Public Class Genetic
    Inherits Disease
    Private _AverageAge As Double
    Private _Type As GeneticType

    Public Sub New(Name As String, TotalPopulation As Integer)
        MyBase.New(Name, TotalPopulation)
    End Sub
    'Properties
    Public Property AverageAge As Double
        Get
            Return _AverageAge
        End Get
        Set(value As Double)
            'Since a person mostly cannot have be 0 and its rare to find someone greater than 10
            'The Above statements is true But Some people do live to weird age so You Never Know
            _AverageAge = ValidateDouble(value)
        End Set
    End Property

    Public Property Type As GeneticType
        Get
            Return _Type
        End Get
        Set(value As GeneticType)
            _Type = value
        End Set
    End Property

    'The solution What 
    Public Function solution() As String
        Dim Ans As String = ""
        If Type.Inherited = True And calcPercPopulation() < 50 Then
            Ans = "Gene Therapy & Intensive Gene Therapy"
        Else
            Ans = "Gene Modification & Advanced Gene Modification"
        End If
        Return Ans
    End Function

    Public Overrides Function display() As String
        Dim tempText As String
        tempText = "Genetic Disease " & Environment.NewLine
        tempText &= MyBase.display() & Environment.NewLine
        tempText &= "Average Age: " & CStr(AverageAge) & Environment.NewLine
        tempText &= "Type Of gene Mutation: " & Type.Name & Environment.NewLine
        tempText &= "Inherited: " & CStr(Type.Inherited) & Environment.NewLine
        tempText &= "Life Span: " & CStr(Type.FindLifeSpan()) & " years" & Environment.NewLine
        tempText &= "Solution : " & CStr(solution()) & Environment.NewLine
        Return tempText
    End Function

End Class