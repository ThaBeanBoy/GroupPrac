﻿Option Strict On
Option Infer Off
Option Explicit On
' ***************************************************************** 
' Team Number: 20
' Team Member 1 Details: Chipoyera, TG (220150124) 
' Team Member 2 Details: Hlebela, JM (221026973) 
' Team Member 3 Details: NDHLOVU, AJ(221020749) 
' Team Member 4 Details: Ntuli, SD (221076674) 
' Practical: Team Project 
' Class name: Disease
' *****************************************************************


<Serializable()> Public MustInherit Class Disease
	Private _Name As String
	Private _PopulationInfected As Integer
	Private _Budget As Double
	Private _Treatable As Boolean

	'We need to find a  way to invoke the total population without using weird method
	Protected _TotalPopulation As Integer

	Public Sub New(Name As String, TotalPopulation As Integer)
		_Name = Name
		_TotalPopulation = TotalPopulation
	End Sub

	Public ReadOnly Property Name() As String
		Get
			Return _Name
		End Get
	End Property

	Public Property PopulationInfected() As Integer
		Get
			Return _PopulationInfected
		End Get
		Set(value As Integer)
			_PopulationInfected = ValidateInteger(value)
		End Set
	End Property

	Public Property Budget() As Double
		Get
			Return _Budget
		End Get
		Set(Value As Double)
			_Budget = ValidateDouble(Value)
		End Set
	End Property

	Public Property Treatable() As Boolean
		Get
			Return _Treatable
		End Get
		Set(Value As Boolean)
			_Treatable = Value
		End Set
	End Property

	Public Overridable Function Improving() As String
		'The Improving The disease part
		'If The disease if treatable / Curable and The Budget is > 100k Then 
		'The Chance of Improving will very high else the 
		'chance of Improving will an all time low

		Dim Ans As String = ""
		If _Treatable And _Budget > 100000 Then
			Ans = "The Disease Is Managable & The Chance of a pandemic is Low"
		ElseIf _Treatable = False And _Budget > 100000 Then
			Ans = "The Disease Is Very Advantageous And The Chances of a Pandemic Is Possible"
		ElseIf _Treatable = False And _Budget < 100000 Then
			Ans = "Disease Has A Very High Chance Of Become Uncontrollable"
		ElseIf _Treatable And _Budget < 100000 Then
			Ans = "The Disease Dooes Not Pose Much Threat To Society"
		Else
			Ans = "You Have Entered Invalid Inputs."
		End If

		Return Ans
	End Function

	Public Overridable Function calcPercPopulation() As Double
		Return (PopulationInfected / _TotalPopulation) * 100
	End Function

	Public Overridable Function FindCategorylevel() As Integer
		Select Case (calcPercPopulation())
			Case 0 To 49
				Return If(_Treatable, 1, 2)
			Case 50 To 70
				Return If(_Treatable, 2, 3)
			Case Else
				Return 3
		End Select
	End Function

	Public Overridable Function display() As String
		Dim Ans As String
		Ans = "Name: " & _Name & Environment.NewLine
		Ans &= "Population Infected: " & CStr(_PopulationInfected) & Environment.NewLine
		Ans &= "Budget: " & Format(_Budget, "#.##") & Environment.NewLine
		Ans &= "Treatable: " & CStr(_Treatable) & Environment.NewLine
		Ans &= "Percentage of Population Infected: " & Format(calcPercPopulation(), "#.##") & Environment.NewLine
		Ans &= "Category Level: " & CStr(FindCategorylevel()) & Environment.NewLine
		Ans &= "Condition : " & Improving() & Environment.NewLine
		Return Ans
	End Function
	'Function To Validate an Integer Number 
	Protected Function ValidateInteger(Number As Integer) As Integer
		If Number < 0 Then
			Return 0
		Else
			Return Number
		End If
	End Function
	'Validate Any Double Values
	Protected Function ValidateDouble(Number As Double) As Double
		If Number < 0 Then
			Return 0
		Else
			Return Number
		End If
	End Function

End Class
