﻿' ***************************************************************** 
' Team Number: 20
' Team Member 1 Details: Chipoyera, TG (220150124) 
' Team Member 2 Details: Hlebela, JM (221026973) 
' Team Member 3 Details: NDHLOVU, AJ(221020749) 
' Team Member 4 Details: Ntuli, SD (221076674) 
' Practical: Team Project 
' Class name: Immune 
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Runtime.Serialization.Formatters.Binary
Public Class Form1
    Private Diseases() As Disease
    Private nD As Integer
    Private FS As FileStream
    Private BF As BinaryFormatter
    Private TotalPopulation As Integer
    Private FileName As String = "Diseasefile.txt"

    Private Sub btnSetUpTheApplication_Click(sender As Object, e As EventArgs) Handles btnSetUpTheApplication.Click
        TotalPopulation = CInt(InputBox("Enter The Population Size of The Area", "Population Size Validation"))
        MsgBox("Total Population Has Been Successfully Captured",, "Population Cormfimation")
    End Sub

    Private Sub btnCaptureTheData_Click(sender As Object, e As EventArgs) Handles btnCaptureTheData.Click
        nD += 1
        ReDim Preserve Diseases(nD)



        Dim choice As Integer = CInt(InputBox("Please select the type of disease" & Environment.NewLine &
                               " 1.Respiratory" & Environment.NewLine &
                               "2.Immune" & Environment.NewLine &
                               "3.Genetic"))
        Dim Name As String = InputBox("Please enter the name of the disease ?")
        Dim Budget As Integer = CInt(InputBox("Please enter the budget available for the disease?"))
        Dim nPopulation As Integer = CInt(InputBox("Please enter the amount of people affected by the disease")) 'My own thing 
        Dim Treatable As Boolean = CBool(InputBox("Is the disease treatable", "TRUE OR FALSE"))



        Select Case choice
            Case 1
                'Resperitory 
                Dim PartAffected As String = InputBox("Please enter the part affrected by the disease?")
                Dim AveCoughes As Double = CDbl(InputBox("Please enter the average coughes  "))
                Dim objRespiratory As Respiratory
                objRespiratory = New Respiratory(Name, TotalPopulation)
                objRespiratory.PopulationInfected = nPopulation
                objRespiratory.Budget = Budget
                objRespiratory.Treatable = Treatable
                objRespiratory.PartAffected = PartAffected
                objRespiratory.AverageNumberOfCoughs = AveCoughes
                'Upcasting 
                Diseases(nD) = objRespiratory
            Case 2
                'Immune 
                Dim NameOfCells As String = (InputBox("Please enter the name of the cells ", "Cell Names"))
                Dim Cause As String = InputBox("Please enter the cause of the disease ", "What Pathogen Caused The Disease")
                Dim objImmune As Immune
                objImmune = New Immune(Name, TotalPopulation)
                objImmune.PopulationInfected = nPopulation
                objImmune.Budget = Budget
                objImmune.Treatable = Treatable
                objImmune.NameOfCells = NameOfCells
                objImmune.Cause = Cause
                'Upcasting 
                Diseases(nD) = objImmune
            Case 3
                'Genetic 
                Dim objGenetic As Genetic
                Dim AverageAge As Double = CDbl(InputBox("Please enter the average age"))
                objGenetic = New Genetic(Name, TotalPopulation)
                objGenetic.PopulationInfected = nPopulation
                objGenetic.Budget = Budget
                objGenetic.Treatable = Treatable
                Dim NameType As String = InputBox("Enter The Name of The Genetic Type", "Genetic Type")
                Dim IsInherited As Boolean = CBool(InputBox("Enter True if it Inherited & False If Not", "Inherited Validation"))
                objGenetic.Type = New GeneticType(NameType)
                objGenetic.Type.Inherited = IsInherited
                'Upcasting 
                Diseases(nD) = objGenetic

        End Select
        'Polymorphism 
        txtDisplay.Clear()
        txtDisplay.Text = "Total Population: " & CStr(TotalPopulation) & Environment.NewLine
        For i As Integer = 1 To nD
            txtDisplay.Text &= Diseases(i).display()
        Next i


        FS = New FileStream(FileName, FileMode.Create, FileAccess.Write)
        BF = New BinaryFormatter

        For i As Integer = 1 To nD
            BF.Serialize(FS, Diseases(i))
        Next i
        MsgBox("Data Was successfully Saved!",, "File Saved")
        FS.Close()
        FS = Nothing
        BF = Nothing
    End Sub

    Private Sub btnFindASolution_Click(sender As Object, e As EventArgs) Handles btnFindASolution.Click
        'To Find The solution Would be based on the classes of diseases That ranked top 3
    End Sub

End Class
